/**
 * Déclarer une variable « msg » avec le mot-clé `const` en lui assignant une
 * valeur de votre choix, telle qu'un message ou un nombre.
 * Afficher la valeur de cette variable dans la console du navigateur.
 */


