## HTML : informations de contact
https://developer.mozilla.org/fr/docs/Web/HTML/Element/address

## HTML : affichage du Favicon
https://www.alsacreations.com/astuce/lire/59-icon-link-rel-favicon-ico-navigateur.html
