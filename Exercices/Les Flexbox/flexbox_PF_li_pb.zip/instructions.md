# Exercice dirigé: Flexbox

## Première étape
- Faire un premier UL LI avec 6 LI
- Remplir les LI avec des lettres ou quelques mots (un grand texte Lorem ne permet pas de visualiser correctement les alignements)
- Appliquer les classes .cards et .parent sur le UL
- Appliquer une premier classe de test (test-1 ou test-default), ajouter la propriété flex à cette classe dans le CSS

## Répéter l'opération pour chaque test
- Dupliquer la liste HTML et la classe CSS, ajouter ou modifier les propriétés CSS
- Mettre un titre adapté
- Attention le dernier test est très différent