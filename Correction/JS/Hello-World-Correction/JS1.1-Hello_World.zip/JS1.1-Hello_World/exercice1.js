/**
 * Afficher "Hello World" dans la console du navigateur.
 */
