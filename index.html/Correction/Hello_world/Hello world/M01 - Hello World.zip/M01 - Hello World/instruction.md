# INSTRUCTIONS
Tout d'abord, pas de CSS avant la partie "CSS".
On se concentre d'abord sur le HTML puis ensuite sur le CSS.
Le but de l'exercice est d'apprendre à utiliser les bonnes balises.

## HTML
- Utilisation des balises sémantiques en priorité, les balises génériques viennent après
- Les images du HTML et du CSS sont appelé en lien relatif et celle du JS, de PHP et de MySQL sont en lien absolu

## CSS
- Police utilisé :
    - Police Serif (par défaut)
    - Arial
    - Monospace

# BONUS
- Trouver comment faire une liste en HTML
