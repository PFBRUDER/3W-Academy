/**
 * Déclarer une variable avec le mot-clé let ayant comme nom « color ».
 * Puis, sur la ligne suivante, lui assigner la valeur « rouge ».
 */

