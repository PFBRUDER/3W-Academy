# Consignes

Utiliser le layout grid pour résoudre cet exercice.

Faire un mockup sur papier peut grandement aider! 

En version bureau, la grille s'étalle sur 80% du viewport en largeur et 100% en hauteur. Dit autrement, il ny a pas de colonnes vides sur les côtés.

La goutière est de 4px;

Les images couvrent leur case respectives.

Si possible, utiliser des directement images (IMG), il faut alors utiliser une propriété spéciale pour bien les caller, sinon utiliser des images de fond (mais c'est moins bon pour le référencement).

